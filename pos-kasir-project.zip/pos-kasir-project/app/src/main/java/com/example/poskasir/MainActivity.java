package com.example.poskasir;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    int blue = Color.rgb(24, 91, 190), pale = Color.rgb(239, 246, 255);
    LinearLayout root, productsBox, cartBox;
    TextView totalText, emptyText;
    EditText nameInput, priceInput;
    Spinner unitSpinner;
    ArrayList<Item> cart = new ArrayList<>();
    ArrayList<Item> products = new ArrayList<>();
    SharedPreferences prefs;

    static class Item {
        String name, unit; int price, qty;
        Item(String n, int p, String u, int q) { name=n; price=p; unit=u; qty=q; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("pos", MODE_PRIVATE);
        loadProducts();
        if (products.size()==0) {
            products.add(new Item("Produk contoh", 10000, "pcs", 0));
            saveProducts();
        }
        buildUI();
    }

    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(12, 8, 12, 8); return t;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue)); return b;
    }
    String rupiah(int n) { return NumberFormat.getCurrencyInstance(new Locale("in","ID")).format(n); }

    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(16,16,16,24); root.setBackgroundColor(pale);
        scroll.addView(root); setContentView(scroll);
        TextView title = text("POS KASIR", 26, blue); title.setGravity(Gravity.CENTER); title.setTypeface(null, 1); root.addView(title);
        root.addView(text("Kasir offline • Biru & putih", 14, Color.DKGRAY));
        root.addView(text("Tambah Produk", 19, blue));
        nameInput = new EditText(this); nameInput.setHint("Nama produk"); root.addView(nameInput);
        priceInput = new EditText(this); priceInput.setHint("Harga (contoh: 15000)"); priceInput.setInputType(2); root.addView(priceInput);
        unitSpinner = new Spinner(this);
        String[] units = {"pcs", "set", "pasang", "box", "liter", "kg"};
        unitSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, units)); root.addView(unitSpinner);
        Button addProduct = button("Simpan Produk"); root.addView(addProduct);
        addProduct.setOnClickListener(v -> {
            String n=nameInput.getText().toString().trim(), p=priceInput.getText().toString().trim();
            if(n.isEmpty() || p.isEmpty()) { toast("Isi nama dan harga produk dulu."); return; }
            try { products.add(new Item(n, Integer.parseInt(p), unitSpinner.getSelectedItem().toString(), 0)); saveProducts(); nameInput.setText(""); priceInput.setText(""); renderProducts(); toast("Produk disimpan di perangkat."); }
            catch(Exception e) { toast("Harga harus berupa angka."); }
        });
        root.addView(text("Daftar Produk — tekan untuk masuk keranjang", 19, blue));
        productsBox = new LinearLayout(this); productsBox.setOrientation(LinearLayout.VERTICAL); root.addView(productsBox);
        root.addView(text("Keranjang Transaksi", 19, blue));
        cartBox = new LinearLayout(this); cartBox.setOrientation(LinearLayout.VERTICAL); root.addView(cartBox);
        totalText = text("Total: Rp0", 21, blue); totalText.setTypeface(null,1); root.addView(totalText);
        Button cancel = button("Batal Transaksi / Kosongkan Keranjang"); root.addView(cancel);
        cancel.setOnClickListener(v -> { cart.clear(); renderCart(); toast("Transaksi dibatalkan."); });
        renderProducts(); renderCart();
    }
    void renderProducts() {
        productsBox.removeAllViews();
        for (Item item: products) {
            Button b = button(item.name + " • " + rupiah(item.price) + " / " + item.unit + "   +");
            productsBox.addView(b);
            b.setOnClickListener(v -> { cart.add(new Item(item.name,item.price,item.unit,1)); renderCart(); });
        }
    }
    void renderCart() {
        cartBox.removeAllViews(); int total=0;
        if(cart.size()==0) cartBox.addView(text("Keranjang masih kosong.", 14, Color.DKGRAY));
        for(int i=0;i<cart.size();i++) {
            final int idx=i; Item it=cart.get(i); total += it.price*it.qty;
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView label=text(it.name+"\n"+it.qty+" "+it.unit+" × "+rupiah(it.price),14,Color.BLACK);
            row.addView(label,new LinearLayout.LayoutParams(0, -2, 1));
            Button minus=button("−"); row.addView(minus); minus.setOnClickListener(v->{ if(cart.get(idx).qty>1) cart.get(idx).qty--; else cart.remove(idx); renderCart(); });
            Button plus=button("+"); row.addView(plus); plus.setOnClickListener(v->{cart.get(idx).qty++;renderCart();});
            cartBox.addView(row);
        }
        totalText.setText("Total: "+rupiah(total));
    }
    void saveProducts() {
        JSONArray arr=new JSONArray();
        try { for(Item i:products){ JSONObject o=new JSONObject(); o.put("name",i.name);o.put("price",i.price);o.put("unit",i.unit);arr.put(o); } }
        catch(Exception ignored) {}
        prefs.edit().putString("products",arr.toString()).apply();
    }
    void loadProducts() {
        try { JSONArray arr=new JSONArray(prefs.getString("products","[]")); for(int i=0;i<arr.length();i++){JSONObject o=arr.getJSONObject(i);products.add(new Item(o.getString("name"),o.getInt("price"),o.getString("unit"),0));} }
        catch(Exception ignored) {}
    }
    void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
