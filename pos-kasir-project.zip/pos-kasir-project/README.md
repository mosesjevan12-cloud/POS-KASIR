# POS Kasir Offline (Android)

Aplikasi kasir sederhana offline dengan tema biru-putih. Fitur awal:
- Tambah produk ke keranjang
- Pilih jumlah dan satuan
- Hitung subtotal dan total
- Batalkan transaksi / kosongkan keranjang
- Penyimpanan daftar produk sederhana di perangkat (SharedPreferences)

## Build APK
Proyek ini memakai Android Gradle Plugin dan GitHub Actions. Workflow ada di `.github/workflows/build-apk.yml`.
Setelah seluruh isi proyek masuk ke repository GitHub, buka tab **Actions**, pilih workflow **Build APK**, lalu jalankan **Run workflow**. APK hasil build akan tersedia di bagian **Artifacts** jika proses berhasil.

Catatan: ini adalah versi awal kasir. Stok otomatis, laporan keuangan, dan ekspor Excel belum termasuk dan bisa ditambahkan setelah versi dasar berhasil dijalankan.
